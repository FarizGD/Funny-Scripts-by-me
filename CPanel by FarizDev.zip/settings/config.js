const settings = {
  token: '8898635867:AAGgGIxzHchgvJ0IZLZiHqvhHQ7YAkZdbyc', // token dari @BotFather
  
  owner: 'farizgd', // jangan di ganti
  ownerId: 7697898730, // user id
  dev: 'farizgd', // wajib username tele
  
  noDana: '085191016145', // nomer dana
  namaDana: 'Fariz', // nama
    
  chUsn: '@farizgd331', // ch tele
  
  exPGroupId: "-1003758887973", // id group
  exGroupId: "-1003758887973", // id group
    
  hostname: "farizvps", // hostname vps
  cfApiToken: "oWm4SD2iMGwLk_MQryXVlOiiBovAlVQxtoADiet7", // api token cloudflare
  cfZoneId: "1b662cae2a8214a8468c97fb552070d0", // zone id domain cf
    
  apiDigitalOcean: "",   // apikey DO
  apiDigitalOcean2: "",  // apikey DO 2  
  apiDigitalOcean3: "",  // apikey DO 3
  apiDigitalOcean4: "",  // apikey DO 4
  apiDigitalOcean5: "",  // apikey DO 5
  apiDigitalOcean6: "",  // apikey DO 6
  apiDigitalOcean7: "",  // apikey DO 7
  apiDigitalOcean8: "",  // apikey DO 8
  apiDigitalOcean9: "",  // apikey DO 9
  apiDigitalOcean10: "", // apikey DO 10
  
  pp: 'https://files.catbox.moe/gqh0er.mp4', // file catbox foto
  ppVid: 'https://files.catbox.moe/gqh0er.mp4', // file catbox video
  panel: 'https://files.catbox.moe/gqh0er.mp4', // foto panel

  qris: 'https://files.catbox.moe/gqh0er.mp4', // qris

  domain: 'https://panel.farizdev.qzz.io', // domain public
  plta: 'ptla_VHcgYpbx59Gz1M0iSMnII9geHDKwGujgcD8jkVzqhye', // ptla panel
  pltc: 'ptlc_0V0fklux1RkbEtOStB0DEFpIjxPb6Av8l9AvedvL3N8', // ptlc panel
    
  domainPriv: '-', // domain private
  pltaPriv: '-', // apikey ptla
  pltcPriv: '-', // apikey ptlc
    
    // PANEL SERVER 2
  domainV2: '-', // domain v2
  pltaV2: '-', // plta v2
  pltcV2: '-', // ptlc v2
    
    // PANEL SERVER 3
  domainV3: '-', // domain v3 
  pltaV3: '-', // ptla v3
  pltcV3: '-', // ptlc v3
    
    // PANEL SERVER 4
  domainV4: '-', // domain v4
  pltaV4: '-', // ptla v4
  pltcV4: '-', // ptlc v4
    
    // PANEL SERVER 5
  domainV5: '-', // domain v5
  pltaV5: '-', // ptla v5
  pltcV5: '-', // ptlc v5
  
  loc: '2', // location id
  eggs: '1' // egg id
};

module.exports = settings;