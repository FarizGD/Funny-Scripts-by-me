const chalk = require("chalk");

async function startBot(bot) {
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  console.clear();
  console.log(chalk.cyan("[BOOT] Connecting to Telegram API..."));
  await sleep(500);

  console.log(chalk.cyan("[BOOT] Validating credentials..."));
  await sleep(450);

  console.log(chalk.cyan("[BOOT] Initializing modules..."));
  await sleep(450);

  const info = await bot.getMe();
  const now = new Date().toLocaleString("en-US", { hour12: false });

  console.clear();
  console.log(chalk.blueBright("==============================================="));
  console.log(chalk.whiteBright("        CPanel Bot by FarizDev Online"));
  console.log(chalk.blueBright("==============================================="));
  console.log(chalk.green(`Bot Name : ${info.first_name}`));
  console.log(chalk.green(`Username : @${info.username}`));
  console.log(chalk.green("Creator  : @FarizDev"));
  console.log(chalk.green("Runtime  : JavaScript (Node.js)"));
  console.log(chalk.green(`Booted   : ${now}`));
  console.log(chalk.gray(`(ubah settings di settings/config.js)`));
  console.log(chalk.blueBright("===============================================\n"));
  console.log(chalk.gray("Ready. Waiting for commands..."));
}

module.exports = startBot;